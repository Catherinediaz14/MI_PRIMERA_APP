package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EncuestaActivity : AppCompatActivity() {

        private lateinit var tvPregunta: TextView
        private lateinit var rgOpciones: RadioGroup
        private lateinit var btnEnviar: Button

        override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.encuesta)

                tvPregunta = findViewById(R.id.tvPregunta)
                rgOpciones = findViewById(R.id.rgOpciones)
                btnEnviar = findViewById(R.id.btnEnviar)

                // Configurar acción al hacer clic en el botón de enviar
                btnEnviar.setOnClickListener {
                        val opcionSeleccionada = obtenerOpcionSeleccionada()

                        if (opcionSeleccionada != null) {
                                // Aquí puedes implementar la lógica para enviar la respuesta
                                // En este ejemplo, simplemente mostramos un mensaje con la opción seleccionada
                                Toast.makeText(this, "Has seleccionado: $opcionSeleccionada", Toast.LENGTH_SHORT).show()
                        } else {
                                Toast.makeText(this, "Selecciona una opción", Toast.LENGTH_SHORT).show()
                        }
                }
        }

        private fun obtenerOpcionSeleccionada(): String? {
                // Obtener la opción seleccionada por el usuario
                val idSeleccionado = rgOpciones.checkedRadioButtonId

        return when (idSeleccionado) {
                R.id.rbOpcion1 -> "Excelente"
                R.id.rbOpcion2 -> "Bueno"
                R.id.rbOpcion3 -> "Regular"
                R.id.rbOpcion4 -> "Malo"
            else -> null
        }
    }
}
