package com.example.myapplication.models

data class aplic(

)
